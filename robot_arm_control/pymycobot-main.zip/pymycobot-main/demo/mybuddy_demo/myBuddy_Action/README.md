# This is Python Demo for myBuddy

## Firmware Requirements: The latest firmware will do

## catch_the_ball

Use myBuddy's hands to grab the ball on the table, move back and forth.

## ChewingGum

Use the gripper to pour the chewing gum out of the table.

## comeOn

Cheer up with red flag in both hands.

## psydack

psyduck dance.

## pass_the_ball

Pass the ball with both hands.

## petCat

pet the cat

## piano

myBuddy plays the song.

## play_ball_cooperatively

myBuddy spins a ball with both hands.

## praise

myBuddy making a thumbs up gesture.

## reject

myBuddy gesture of rejection with both hands.

## symphony

myBuddy conducts like a musician.

## thanHeart

myBuddy making a heart gesture with both hands.

## dence

myBuddy's dance.