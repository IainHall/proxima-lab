# 使用方法

1. 先将myArm M连接电脑
2. 执行myarm_m.py，输入myarm_m端口号对应的序号
3. 再将myArm C连接电脑
4. 执行myarm_c.py，输入myarm_c端口号对应的序号

**注：** myarm_m.py包含服务器，需先于myarm_m.py启动

------------------------------------------------------------------------

# Usage

1. Connect myArm M to the computer first
2. Execute myarm_m.py and enter the serial number corresponding to the myarm_m port number
3. Then connect myArm C to the computer
4. Execute myarm_c.py and enter the serial number corresponding to the myarm_c port number

**Note:** myarm_m.py contains the server and must be started before myarm_m.py