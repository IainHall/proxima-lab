# 使用说明
## 使用说明
* "Client.py"是客户端的样例，使用在你的电脑中运行
* "Servo.py"是服务器端的执行文件，在机械臂中运行
## 参考内容
* [Socket 使用解析](https://blog.csdn.net/pashanhu6402/article/details/96428887?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522162392592016780357215629%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=162392592016780357215629&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~top_positive~default-1-96428887.first_rank_v2_pc_rank_v29&utm_term=socket&spm=1018.2226.3001.4187)

* [mycobot 使用说明](https://www.elephantrobotics.com/docs/myCobot/)

* [Scoket 函数解析](https://www.runoob.com/python/python-socket.html)